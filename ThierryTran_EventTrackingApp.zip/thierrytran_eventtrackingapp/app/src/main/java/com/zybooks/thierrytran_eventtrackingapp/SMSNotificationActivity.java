package com.zybooks.thierrytran_eventtrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    private ActivityResultLauncher<String> requestPermissionLauncher;
    private EditText phoneNumberInput;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        sharedPreferences = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);

        phoneNumberInput = findViewById(R.id.phone_number_input);
        Button requestPermissionButton = findViewById(R.id.request_sms_permission_button);
        requestPermissionButton.setOnClickListener(v -> {
            savePhoneNumber();
            requestSMSPermission();
        });

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        // Permission granted, show notifications
                        showNotifications();
                    } else {
                        // Permission denied
                        Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    private void savePhoneNumber() {
        String phoneNumber = phoneNumberInput.getText().toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("phoneNumber", phoneNumber);
        editor.apply();
    }

    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            showNotifications();
        } else {
            // Request permission
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void showNotifications() {
        // Implement logic to show notifications
        Toast.makeText(this, "SMS permission granted. Notifications will be sent.", Toast.LENGTH_SHORT).show();
    }
}
