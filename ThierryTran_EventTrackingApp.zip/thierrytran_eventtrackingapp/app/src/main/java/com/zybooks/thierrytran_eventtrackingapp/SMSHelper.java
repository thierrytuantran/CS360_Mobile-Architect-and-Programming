package com.zybooks.thierrytran_eventtrackingapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.telephony.SmsManager;

public class SMSHelper {

    public static void sendSMS(Context context, String message) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("EventTrackerPrefs", Context.MODE_PRIVATE);
        String phoneNumber = sharedPreferences.getString("phoneNumber", null);

        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        }
    }
}
