package com.zybooks.thierrytran_eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameField = findViewById(R.id.username);
        passwordField = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        Button createLoginButton = findViewById(R.id.register_button);

        loginButton.setOnClickListener(v -> login());
        createLoginButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
        });
    }

    private void login() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        // Implement your login logic here

        // Check if username and password are correct (simple check for example purposes)
        if (!username.isEmpty() && !password.isEmpty()) {
            Intent intent = new Intent(this, DataDisplayActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Please enter valid credentials", Toast.LENGTH_SHORT).show();
        }
    }
}
