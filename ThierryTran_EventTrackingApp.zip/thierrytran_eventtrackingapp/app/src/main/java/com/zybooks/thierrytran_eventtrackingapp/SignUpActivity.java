package com.zybooks.thierrytran_eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    private EditText firstNameField;
    private EditText lastNameField;
    private EditText phoneNumberField;
    private EditText emailAddressField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        firstNameField = findViewById(R.id.first_name);
        lastNameField = findViewById(R.id.last_name);
        phoneNumberField = findViewById(R.id.phone_number);
        emailAddressField = findViewById(R.id.email_address);
        Button signUpButton = findViewById(R.id.sign_up_button);
        Button cancelButton = findViewById(R.id.cancel_button);

        signUpButton.setOnClickListener(v -> signUp());
        cancelButton.setOnClickListener(v -> cancel());
    }

    private void signUp() {
        String firstName = firstNameField.getText().toString();
        String lastName = lastNameField.getText().toString();
        String phoneNumber = phoneNumberField.getText().toString();
        String emailAddress = emailAddressField.getText().toString();

        // Perform sign-up logic here (e.g., save to database, validate inputs, etc.)
        // For now, just show a toast message
        Toast.makeText(this, "Sign Up Successful", Toast.LENGTH_SHORT).show();

        // Redirect to the login screen
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void cancel() {
        // Redirect to the login screen without saving
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
