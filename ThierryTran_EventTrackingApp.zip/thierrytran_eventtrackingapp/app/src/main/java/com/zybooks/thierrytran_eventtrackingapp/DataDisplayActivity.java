package com.zybooks.thierrytran_eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private List<String> eventList;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("T3 Event Tracker");

        eventList = new ArrayList<>();
        adapter = new EventAdapter(eventList);

        RecyclerView recyclerView = findViewById(R.id.data_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        Button addDataButton = findViewById(R.id.add_data_button);
        addDataButton.setOnClickListener(v -> showAddEventDialog());

        Button smsNotificationButton = findViewById(R.id.sms_notification_button);
        smsNotificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SMSNotificationActivity.class);
            startActivity(intent);
        });
    }

    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_event, null);
        builder.setView(dialogView);

        EditText eventNameInput = dialogView.findViewById(R.id.event_name_input);
        Button addButton = dialogView.findViewById(R.id.add_event_button);

        AlertDialog dialog = builder.create();

        addButton.setOnClickListener(v -> {
            String eventName = eventNameInput.getText().toString();
            if (!eventName.isEmpty()) {
                eventList.add(eventName);
                adapter.notifyItemInserted(eventList.size() - 1);
                dialog.dismiss();
            } else {
                Toast.makeText(this, "Event name cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }
    private void notifyEvent(String eventName) {
        String message = "Reminder: Your event " + eventName + " is coming up!";
        SMSHelper.sendSMS(this, message);
    }

}
